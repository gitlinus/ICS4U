/*
Linus Chen
ICS4U1
Name class
*/

import java.util.*;

public class Name {
	private String first;
	private String last;
	public Name(String last, String first){ //constructor
		this.first = first;
		this.last = last;
	}

	public String getFirst(){return first;}
	public String getLast(){return last;}
	public String toString(){return last+", "+first;} //return string of name

	public static class CompareNames implements Comparator<Name>{ //custom comparator for Name object
		public int compare(Name n1, Name n2){
			if(n1.last.compareTo(n2.last)==0) return n1.first.compareTo(n2.first);
			return n1.last.compareTo(n2.last);
		}
	}
}