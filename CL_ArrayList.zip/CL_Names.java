/*
Linus Chen
ArrayList Names object 
ICS4U1
*/

import java.util.*;
import java.io.*;
import java.lang.*;
import java.awt.*;
import javax.swing.*;

public class CL_Names {
	private ArrayList<Name> names;

	public CL_Names(){ //default constructor
		names = new ArrayList<Name>();
	}

	public CL_Names(String filename){ //new list from file 
		names = new ArrayList<Name>();
        try{
            Scanner sc = new Scanner(new File(filename));
            try{ while(sc.hasNextLine()){
	                String s = sc.nextLine();
	                int idx = s.indexOf(" ");
	                names.add(new Name(s.substring(0,idx),s.substring(idx+1)));
	          	}
          	}
          	catch(StringIndexOutOfBoundsException e){ //pop up error message
          		JOptionPane optionPane = new JOptionPane("Invalid File Type", JOptionPane.ERROR_MESSAGE);
				JDialog dialog = optionPane.createDialog("Invalid File");
				dialog.setAlwaysOnTop(true);
				dialog.setVisible(true);
          	}
        } catch (FileNotFoundException e){ //pop up error message
        	JOptionPane optionPane = new JOptionPane("File not found :(\nFile must be in the same directory", JOptionPane.ERROR_MESSAGE);
			JDialog dialog = optionPane.createDialog("File Not Found Error");
			dialog.setAlwaysOnTop(true);
			dialog.setVisible(true);
        }
	}

	public CL_Names (ArrayList<Name> list){ //new list from another list
		names = new ArrayList<Name>();
		for(Name n : list) names.add(n);
	}

	public String toString(){ //return the list as a string
		String res = "";
		for(Name n : names) res += n.getLast() + ", " + n.getFirst() + "\n";
		return res;
	}

	public CL_Names search(char letter){ //search for names
		ArrayList<Name> res = new ArrayList<Name>();
		for(Name n : names)if(n.getLast().charAt(0)==letter)res.add(n);
		return new CL_Names(res);
	}

	public CL_Names search(String surname){ //search for names
		ArrayList<Name> res = new ArrayList<Name>();
		for(Name n : names)if(n.getLast().equals(surname))res.add(n);
		return new CL_Names(res);
	}

	public void add(Name name){ //add another name
		names.add(name);
	}

	public void remove(int idx){ //remove the name at index idx
		if(idx>=0&&idx<names.size())
			names.remove(idx);
	}

	public void sort(){ //sort the list
		Collections.sort(names, new Name.CompareNames());
	}	

	public ArrayList<Name> getList(){ //return the list
		return names;
	}
}