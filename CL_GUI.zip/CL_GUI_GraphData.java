/*
Linus Chen
This class gets the input data for the bargraph through GUI
ICS4U1
*/

import java.util.*;
import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CL_GUI_GraphData extends JFrame implements ActionListener{

	private JComboBox selection; //number of categories to choose
	private String[] select = new String[]{"1", "2", "3", "4", "5", "6"};
	private JButton choose, generate; //selection buttons
	private int numSelected; //records selected choice
	private JTextField[] fillcategories; //will hold array of categories inputed
	private JTextField[] fillnum; //will hold array of numbers inputed
	private JFrame menu; //will be needed later
	private int[] elements; //used to hold converted integer from textfield
	private String[] names; //used to hold converted string from textfield
	private Data export; //data to be used by CL_GUI_Graph

	public CL_GUI_GraphData(){ //constructor
		super("Enter Data");
		setSize(200,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        setLayout(new FlowLayout());
        selection = new JComboBox(select);
        choose = new JButton("Choose # of categories:");
        choose.addActionListener(this);
        choose.setActionCommand("choice");
		generate = new JButton("Generate");
		generate.addActionListener(this);
		generate.setActionCommand("generate");
        add(choose);
        add(selection);
	}

	public boolean isValidInput(){ //checks if user inputs valid information in textfield and converts the textfield data into the int and String arrays if it is
		int flag = 0;
		for(int i=0; i<numSelected; i++){
			try{ elements[i] = Integer.parseInt(fillnum[i].getText()); if(elements[i]<0)throw new IllegalArgumentException();} //checks if number inputed are integer values
			catch(IllegalArgumentException e){ flag = 1;}
			try{
				if(fillcategories[i].getText().trim().isEmpty()) throw new IllegalArgumentException(); //checks if input was blank
				else names[i] = fillcategories[i].getText();
			}
			catch(IllegalArgumentException e){ flag = 1;}
		}
		if(flag==0) return true; //input valid
		//display error message
		JOptionPane optionPane = new JOptionPane("You're a big troll!\nFill in valid data for each text field!", JOptionPane.ERROR_MESSAGE);
		JDialog dialog = optionPane.createDialog("Invalid Data Input");
		dialog.setAlwaysOnTop(true);
		dialog.setVisible(true);
		return false;
	}	

	public void actionPerformed(ActionEvent evt){ //instructions for buttons
		if(evt.getActionCommand().equals("choice")){
			numSelected = selection.getSelectedIndex()+1; //sets up the input JFrame
			menu = new JFrame("Enter Data");
			//set window attributes of menu
			menu.setSize(400,100 + numSelected*50);
			menu.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			menu.setResizable(false);
			menu.setVisible(true);
			menu.setLayout(new GridLayout(0, 2, 10, 10));
			JLabel label1 = new JLabel("Category");
			JLabel label2 = new JLabel("Number");
			menu.add(label1);
			menu.add(label2);
			fillcategories = new JTextField[numSelected];
			fillnum = new JTextField[numSelected];
			for(int i=0; i<numSelected; i++){
				fillcategories[i] = new JTextField(15); //initialize textfields and add to menu frame
				fillnum[i] = new JTextField(15);
				menu.add(fillcategories[i]);
				menu.add(fillnum[i]);
			}
			menu.add(generate);
		}
		else if(evt.getActionCommand().equals("generate")){
			elements = new int[numSelected];
			names = new String[numSelected];
			if(isValidInput()){ //check if input is valid
				export = new Data(numSelected); //make Data object
				export.input(elements, names); //input information into Data object
				CL_GUI_Graph bargraph = new CL_GUI_Graph(export); //make new graph with the information
				bargraph.setVisible(true);
			}
		}
	}
}