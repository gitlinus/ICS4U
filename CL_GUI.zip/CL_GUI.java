/*
Linus Chen
Runner program for the GUI assignment
ICS4U1
*/

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.lang.*;

public class CL_GUI {
	
	static Scanner sc;

	public static void main(String[] args){
		sc = new Scanner(System.in);
		//menu
		System.out.println("GUI Exercises:\n");
		int choice;

		System.out.printf("1. String Problems\n");
		System.out.printf("2. Bar Graph\n");
		System.out.printf("0. Quit\n\n");
		choice = sc.nextInt();
		
		if(choice==1){
			CL_GUI_Strings strings = new CL_GUI_Strings();
			strings.setVisible(true);
		}
		else if(choice == 2){
			CL_GUI_GraphData graph = new CL_GUI_GraphData();
			graph.setVisible(true);
		}
	}
}