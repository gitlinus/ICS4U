/*
Linus Chen
ICS4U1
MapMaker assignment
*/

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;  // Needed for ActionListener
import java.util.*;  // Needed for Scanner
import java.io.*; // file IO

public class CL_Map extends JFrame implements MouseListener, ActionListener {
    Map map = new Map (40,30,20,20);
    JComboBox itemBox;
    //======================================================== constructor
    public CL_Map ()
    {
        // 1... Create/initialize components
        JButton searchBtn = new JButton ("Search");
        searchBtn.addActionListener (this);
        JButton saveBtn = new JButton ("Save");
        saveBtn.addActionListener (this);
        JButton loadBtn = new JButton ("Load");
        loadBtn.addActionListener (this);
        String list[] = {"Space","Wall","Treasure","Door","Key","Monster"};
        itemBox = new JComboBox(list);

        // 2... Create content pane, set layout
        JPanel content = new JPanel ();        // Create a content pane
        content.setLayout (new BorderLayout ()); // Use BorderLayout for panel
        JPanel north = new JPanel (); // where the buttons, etc. will be
        north.setLayout (new FlowLayout ()); // Use FlowLayout for input area

        DrawArea board = new DrawArea (800, 600); // Area for cards to be displayed

        // 3... Add the components to the input area.
        north.add (searchBtn);
        north.add (saveBtn);
        north.add (loadBtn);
        north.add (itemBox);
        content.add (board, "North"); // Deck display area
        content.add (north, "South"); // Input area
        

        content.addMouseListener(this);

        // 4... Set this window's attributes.
        setContentPane (content);
        pack ();
        setTitle ("MapMaker Assignment");
        setSize (800, 700);
        setResizable(false);
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo (null);           // Center window.
    }

    public void actionPerformed (ActionEvent e)
    {
        if (e.getActionCommand ().equals ("Search"))
            map.search (); // search for and count items
        else if (e.getActionCommand ().equals ("Save"))
        {
        	// get file from JFileChooser
            JFileChooser chooser = new JFileChooser("."); //show current directory files
			int returnVal = chooser.showOpenDialog(CL_Map.this);
			if(returnVal == JFileChooser.APPROVE_OPTION) {
		       	map.save(chooser.getSelectedFile().getName()); // load map
		    }
        }
        else if (e.getActionCommand ().equals ("Load"))
        {
            // get file from JFileChooser
            JFileChooser chooser = new JFileChooser("."); //show current directory files
			int returnVal = chooser.showOpenDialog(CL_Map.this);
			if(returnVal == JFileChooser.APPROVE_OPTION) {
		       	map.load(chooser.getSelectedFile().getName()); // load map
		    }
        }
        repaint (); // do after each action taken to update deck
    }

    class DrawArea extends JPanel //DrawArea class
    {
        public DrawArea (int width, int height)
        {
            this.setPreferredSize (new Dimension (width, height)); // size
        }

        public void paintComponent (Graphics g)
        {
            map.print (g); //draw the map in the given area
        }
    }

    // Must implement all methods from listener
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {
        System.out.println(e.getX() + ", "+e.getY());
  		String choice = (String) itemBox.getSelectedItem();
  		System.out.println(choice);
  		map.add(e.getY()/map.getHeight(), e.getX()/map.getWidth(), choice.charAt(0));      
        repaint();
    }    

    //======================================================== method main
    public static void main (String[] args)
    {
        CL_Map window = new CL_Map ();
        window.setVisible (true);
    }
}

class Map //Map class
{
    private char map [] [];
    private int width, height;

    public Map (int cols, int rows, int blockwidth, int blockheight) // set up default map
    {
        width = blockwidth;  height = blockheight;
        map = new char [rows] [cols]; // define 2-d array size

        for (int row = 0 ; row < rows ; row++)
            for (int col = 0 ; col <cols ; col++)
            {
                if (row == 0 || row == rows-1 || col == 0 || col == cols-1) 
                    map [row] [col] = 'W'; // put up a wall
                else
                    map [row] [col] = 'S'; // blank space
        }
        map[rows-1][cols/2] = 'D'; // make a door
        map[rows-1][cols/2+1] = 'D';
    }

    public void print (Graphics g)  // displays the map on the screen
    {
        for (int row = 0 ; row < map.length; row++)// number of rows
        {
            for (int col = 0 ; col < map[0].length; col++)// length of first row
            {
            	boolean exists = true; //holds condition if given current map element is valid
                if (map [row] [col] == 'W') // wall
                    g.setColor (Color.black);
                else if (map [row] [col] == 'D') // door
                    g.setColor (Color.red);
                else if (map [row] [col] == 'M') // monster
                    g.setColor (Color.green);
                else if (map [row] [col] == 'T') // treasure
                    g.setColor (Color.yellow);
                else if (map [row] [col] == 'K') // key
                    g.setColor (Color.blue);
                else if (map [row] [col] == 'S') // space will erase what was there
                    g.setColor (Color.white);
                else exists = false; //check if the map element is valid
                if(!exists) g.setColor(Color.white); //draw a space in place of invalid object
                g.fillRect (col * width, row * height, width, height); // draw block
            }
        }
    }

    public int getWidth(){return width;} //get the width of the map
    public int getHeight(){return height;} //get the height of the map

    public void add(int x, int y, char item) //add element to the map
    {
    	try{
			System.out.println("Row: "+x+", Col: "+y);
			System.out.println();
			map[x][y] = item; //add element to the map
			if(item=='W'){ //check if item elected is a wall
				if(y==0) for(int i=0; i<map[0].length; i++) map[x][i] = item; //add entire column
				if(x==0) for(int i=0; i<map.length; i++) map[i][y] = item; //add entire row
			}
		}catch(ArrayIndexOutOfBoundsException e){ //prevents the program from crashing if user clicks outside of the DrawArea
			System.out.println("User did not click within map area");
			System.out.println();
		}
    }

    public void save(String fileName) //save current map as a file
    {
    	try{ //write the map array into a file
	    	PrintWriter writer = new PrintWriter(fileName);
	    	for(int i=0; i<map.length; i++){
	    		for(int j=0; j<map[0].length; j++)
	    			writer.print(map[i][j]);
	    		writer.println();
	    	}
			writer.close();
		}catch (FileNotFoundException e){ //pop up error message
        	JOptionPane optionPane = new JOptionPane("File not found :(\nFile must be in the same directory", JOptionPane.ERROR_MESSAGE);
			JDialog dialog = optionPane.createDialog("File Not Found Error");
			dialog.setAlwaysOnTop(true);
			dialog.setVisible(true);
        }
    }

    public void load(String fileName) //load a map
    {
    	try{
            Scanner sc = new Scanner(new File(fileName));
            int cur = 0;
            try{ 
            	boolean valid = true; //holds condition of map loaded has invalid items
            	while(sc.hasNextLine()){
	                String s = sc.nextLine();
	                for(int i=0; i<s.length(); i++){
	                	map[cur][i] = (s.charAt(i));
	                	if(map[cur][i]!='W'&&map[cur][i]!='T'&&map[cur][i]!='M'&&map[cur][i]!='D'&&map[cur][i]!='S'&&map[cur][i]!='K') valid = false;
	                	System.out.print(map[cur][i]+" ");
	                }
	                cur++;
	                System.out.println();
	          	}
	          	if(!valid){ //show warning message
	          		JOptionPane optionPane = new JOptionPane("Map contains invalid objects\nSpaces were drawn instead", JOptionPane.ERROR_MESSAGE);
					JDialog dialog = optionPane.createDialog("WARNING");
					System.out.println("Map contains invalid objects\nSpaces were drawn instead");
					dialog.setAlwaysOnTop(true);
					dialog.setVisible(true);
	          	}
          	}
          	catch(ArrayIndexOutOfBoundsException e){ //pop up error message, map is too big
          		JOptionPane optionPane = new JOptionPane("Map is not within 40 x 30", JOptionPane.ERROR_MESSAGE);
				JDialog dialog = optionPane.createDialog("Invalid File");
				System.out.println("Invalid File");
				dialog.setAlwaysOnTop(true);
				dialog.setVisible(true);
          	}
        } catch (FileNotFoundException e){ //pop up error message, file not found
        	JOptionPane optionPane = new JOptionPane("File not found :(\nFile must be in the same directory", JOptionPane.ERROR_MESSAGE);
			JDialog dialog = optionPane.createDialog("File Not Found Error");
			System.out.println("File not found");
			dialog.setAlwaysOnTop(true);
			dialog.setVisible(true);
        }
        System.out.println();
	}

    public void search() //search elements in the map
    {
    	int spaces=0, walls=0, treasure=0, doors=0, monsters=0, keys=0;
    	for(int i=0; i<map.length; i++) 
    		for(int j=0; j<map[0].length; j++) { //count all of the items
    			if(map[i][j]=='S') spaces++;
    			if(map[i][j]=='W') walls++;
    			if(map[i][j]=='T') treasure++;
    			if(map[i][j]=='D') doors++;
    			if(map[i][j]=='M') monsters++;
    			if(map[i][j]=='K') keys++;
    		}
    	JFrame displaySearchResults = new JFrame("Search Results"); //output results in a new window
    	displaySearchResults.setSize(200,300);
    	displaySearchResults.setLayout(new GridLayout(6,0));
    	displaySearchResults.add(new JLabel("\tSpaces: "+spaces));
    	displaySearchResults.add(new JLabel("\tWalls: "+walls));
    	displaySearchResults.add(new JLabel("\tTreasures: "+treasure));
    	displaySearchResults.add(new JLabel("\tDoors: "+doors));
    	displaySearchResults.add(new JLabel("\tMonsters: "+monsters));
    	displaySearchResults.add(new JLabel("\tKeys: "+keys));
    	displaySearchResults.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    	displaySearchResults.setVisible(true);
    }
}