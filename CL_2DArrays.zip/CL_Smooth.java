/*
Linus Chen
ICS4U1
Smooth Array GUI
*/

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.*;
import javax.swing.*;

public class CL_Smooth extends JFrame{

	int x, y; //declare variables
	static boolean done = false;
	static int[][] arr;
	static JButton init = new JButton("Select File");
	static JButton generate = new JButton("Smooth Array");

	public CL_Smooth(){
		super("Image Smoother");
		//set attributes of components
		JPanel pane = new JPanel();
		DrawArea drawarea = new DrawArea(500,500);

		init.addActionListener(new buttonListener());
		generate.addActionListener(new buttonListener());
		//add elements to the JPanel
		pane.setLayout(new FlowLayout());
		pane.add(init);
		pane.add(generate);
		pane.add(drawarea);

		//set window attributes
		setContentPane(pane);
		pack();
		setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
	}

	public void printArr(){ //prints the array in std output to check
		System.out.println();
		for(int i=0; i<arr.length; i++){
			for(int j=0; j<arr[0].length; j++)
				System.out.print(arr[i][j]+" ");
			System.out.println();
		}
		System.out.println();
	}

	public void memset(int[][] array, int val){ //same as memset function in c++, assigns all values of given array to val
		for(int i=0; i<array.length; i++) for(int j=0; j<array[0].length; j++) array[i][j] = val;
	}

	public void read(String filename){ //read from a file
		try{
            Scanner sc = new Scanner(new File(filename));
            try{ 
            	int[][] temp = new int[500][500]; //set max grid to 500,500
            	memset(temp, 0);
            	int height=0, width=0, row=0, col=0;
            	while(sc.hasNextLine()){
	                String s = sc.nextLine();
	                for(int i=0; i<s.length(); i+=2){
	                	temp[row][col] = (int)(s.charAt(i)-'0');
	                	col++;
	                }
	                width = col;
	                row++;
	                col = 0;
	          	}
	          	height = row;
	          	arr = new int[height][width]; //add the input to the array
	          	for(int i=0; i<height; i++)
	          		for(int j=0; j<width; j++)
	          			arr[i][j] = temp[i][j];
          	}
          	catch(ArrayIndexOutOfBoundsException e){ //pop up error message
          		JOptionPane optionPane = new JOptionPane("File is too big :(", JOptionPane.ERROR_MESSAGE);
				JDialog dialog = optionPane.createDialog("Invalid File");
				dialog.setAlwaysOnTop(true);
				dialog.setVisible(true);
          	}
        } catch (FileNotFoundException e){ //pop up error message
        	JOptionPane optionPane = new JOptionPane("File not found :(\nFile must be in the same directory", JOptionPane.ERROR_MESSAGE);
			JDialog dialog = optionPane.createDialog("File Not Found Error");
			dialog.setAlwaysOnTop(true);
			dialog.setVisible(true);
        }
	}

	public void smooth(){ //smooth calculations
		int[][]temp = new int[arr.length][arr[0].length];
		memset(temp,0);
		for(int i=0; i<arr.length; i++){
			for(int j=0; j<arr[0].length; j++){
				if(i==0){ //check corners
					if(j==0) temp[i][j] = (arr[i][j]+arr[i+1][j]+arr[i][j+1]+arr[i+1][j+1])/4;
					else if(j==arr[0].length-1) temp[i][j] = (arr[i][j]+arr[i+1][j]+arr[i][j-1]+arr[i+1][j-1])/4;
					else temp[i][j] = (arr[i][j]+arr[i+1][j]+arr[i][j-1]+arr[i][j+1]+arr[i+1][j-1]+arr[i+1][j+1])/6;
				}
				else if(i==arr.length-1){ //check corners
					if(j==0) temp[i][j] = (arr[i][j]+arr[i-1][j]+arr[i][j+1]+arr[i-1][j+1])/4;
					else if(j==arr[0].length-1) temp[i][j] = (arr[i][j]+arr[i-1][j]+arr[i][j-1]+arr[i-1][j-1])/4;
					else temp[i][j] = (arr[i][j]+arr[i-1][j]+arr[i][j-1]+arr[i][j+1]+arr[i-1][j-1]+arr[i-1][j+1])/6;
				}
				else if(j==0){ //check if on border
					temp[i][j] = (arr[i][j]+arr[i+1][j]+arr[i-1][j]+arr[i-1][j+1]+arr[i][j+1]+arr[i+1][j+1])/6;
				}
				else if(j==arr[0].length-1){ //check if on border
					temp[i][j] = (arr[i][j]+arr[i+1][j]+arr[i-1][j]+arr[i-1][j-1]+arr[i][j-1]+arr[i+1][j-1])/6;
				}
				else{ //non-border and non-corner areas are evaluated the same way
					temp[i][j] = (arr[i][j]+arr[i+1][j]+arr[i-1][j]+arr[i][j+1]+arr[i][j-1]+arr[i+1][j-1]+arr[i+1][j+1]+arr[i-1][j-1]+arr[i-1][j+1])/9;
				}
			}
		}
		arr = temp;
	}


	class buttonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){ 
			if(e.getSource()==init){ //find which buttom was pressed
				JFileChooser chooser = new JFileChooser("."); //show current directory files
				int returnVal = chooser.showOpenDialog(CL_Smooth.this);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
			       	read(chooser.getSelectedFile().getName());
			       	System.out.println("Original Array:");
			       	printArr();
			       	done = true;
			       	repaint();
			    }
			}
			else if(e.getSource()==generate){
				smooth();
				System.out.println("Smoothed Array:");
				printArr();
				done = true;
				repaint();
			}
		}
	}	

	class DrawArea extends JPanel
    {
    	int w, h;
    	public DrawArea (int width, int height)  // Create panel of given size
        {
            this.setPreferredSize (new Dimension (width, height));
            w = width;
            h = height;
        }

        public void paintComponent (Graphics g)  // g can be passed to a class method
        {
        	if(done){
	        	x = w/arr[0].length;
	        	y = h/arr.length;
	            for(int i=0; i<arr.length; i++){
	            	for(int j=0; j<arr.length; j++){
	            		g.setColor(new Color(arr[i][j]*50,arr[i][j]*50,arr[i][j]*50)); //scale of shade of gray
	            		g.fillRect(i*x,j*y,x,y);
	            	}
	            }
        	}
        }
    }

	public static void main(String[] args){ //main
		CL_Smooth smoother = new CL_Smooth();
		smoother.setVisible(true);
	}
}