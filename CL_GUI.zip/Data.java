/*
Linus Chen
Data class to store input from CL_GUI_GraphData
ICS4U1
*/

public class Data {
	private int numCategories; //data size (number of data entries)
	private int[] numOfEach; //stores values of each category
	private String[] categories; //stores names of each category

	public Data(int num){ //constructor
		numCategories = num;
		numOfEach = new int[numCategories];
		categories = new String[numCategories];
	}

	public void input(int[] elements, String[] cats){ //used to get input
		for(int i=0; i<numCategories; i++){
			numOfEach[i] = elements[i];
			categories[i] = cats[i];
		}
	}

	public void output(){ //output data
		for(int i=0; i<numCategories; i++) System.out.printf("%s %d\n", categories[i], numOfEach[i]);
	}

	public int getNum(){ //returns size of the data (number of data entries)
		return numCategories;
	}

	public int getElementNum(int idx){ //returns the value at current index
		return numOfEach[idx];
	}

	public String getElementCat(int idx){ //returns the category at current index
		return categories[idx];
	}	

	public int[] getNumArray(){ //returns the entire array of values
		return numOfEach;
	}

	public String[] getCategories(){ //returns the entire array of categories
		return categories;
	}
}