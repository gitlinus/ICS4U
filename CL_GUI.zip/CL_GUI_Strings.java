/*
Linus Chen
GUI implementation of Strings problem set
ICS4U1
*/

import java.util.*;
import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CL_GUI_Strings extends JFrame implements ActionListener{
	//declare variables
	private JTextField pal, shift, encode;
	private JButton b_pal, b_shift, b_encode;
	private String[] values = new String[26];
	private JComboBox select;

	public CL_GUI_Strings(){ //constructor
		super("STRINGS");
		//set window attributes
		setSize(420,160);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        setLayout(new FlowLayout());

        for(int i=0;i<26;i++)
            values[i] = Integer.toString(i);

       	select = new JComboBox(values);

        pal = new JTextField(20);
        shift = new JTextField(20);
        encode = new JTextField(20);
        b_pal = new JButton("Palindrome?");
        b_shift = new JButton("Shift");
        b_encode = new JButton("Encode");
        b_pal.addActionListener(this);
        b_shift.addActionListener(this);
        b_encode.addActionListener(this);
        b_pal.setActionCommand("pal");
		b_shift.setActionCommand("shift");
        b_encode.setActionCommand("encode");

        add(pal);
        add(b_pal);
        add(shift);
        add(b_shift);
        add(select);
        add(encode);
        add(b_encode);
	}

	public void actionPerformed(ActionEvent evt){//action for when buttons are pressed
		if(evt.getActionCommand().equals("pal")){ //gets the input from the textfield and calls the string class to perform method on the input
			String str = pal.getText();
			boolean res = CLStrings.isPalindrome(str); 
			pal.setText(res?str+" is a palindrome":str+" is not a palindrome"); //output result into textfield
		}else if(evt.getActionCommand().equals("shift")){
			String str = shift.getText();
			int sh = select.getSelectedIndex();
			String res = CLStrings._shift(str,sh);
			shift.setText(res);
		}
		else{
			String str = encode.getText();
			String res = CLStrings.genScram();
			System.out.println("\nScramble Alphabet: \n"+res);
			encode.setText(CLStrings.encrypt(str,res));
		}
	}
}