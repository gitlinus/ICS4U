/*
Linus Chen
ICS4U1
Bar Graph class
Generates Bar Graph from data given
*/

import java.util.*;
import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.*;

public class CL_GUI_Graph extends JFrame{

	private Data data;

	public CL_GUI_Graph(Data d){ //constructor
		super("Bar Graph");
		data = d;

		Graph g = new Graph(data,800,600);
		add(g);
		//set window attributes
		setSize(800,600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	class Graph extends JPanel{
		private int length, height; //length and height of axes
		private Data data; //data for graph
		public Graph(Data d, int length, int height){ //constructor
			data = d;
			this.length = length - 100;
			this.height = height - 100;
			repaint();
		}

		private int getMax(){//finds the largest number in the data
			int max = data.getElementNum(0);
			for(int i=0; i<data.getNum(); i++){
				if(max<data.getElementNum(i))
					max = data.getElementNum(i);
			}
			return max;
		}

		private int findMultiple(){//find the multiple of ten (because im using ten ticks) that will fit the largest number
			int res = 1;
			while(10*res<getMax()) res ++;
			return res;
		}

		private int getBarHeight(int n, int tick){ //function to find the height of a bar as a function of the length of the y axis in pixels and use that to determine the y coordinate
			int val = data.getElementNum(n);
			int numTicks = 0;
			while(val>=(numTicks+1)*tick) numTicks++; //find the number of ticks that the bar surpasses since 1 tick = 50 pixels in length
			return height - (numTicks*50 + (int)(((double)(val-numTicks*tick)/(double)tick)*50)); //calculates the starting y coordinate of the bar 
		}

		public void paint(Graphics g){ //paint function, draws the graph
			Graphics2D g2 = (Graphics2D) g;
			g.drawLine(100,height,length+100,height);
			g.drawLine(100,0,100,height);
			FontMetrics fontMetrics = g.getFontMetrics();

			int tick = findMultiple(); //find the scaling of the ticks
			for(int i=10; i>=0; i--){
				String cur = Integer.toString(tick*(10-i));
				g.drawString(cur,90-fontMetrics.stringWidth(cur),i*50+10);
				g.drawLine(95,i*50,105,i*50);
			}
			
			int barWidth = length/(data.getNum()*2+1); //width of a bar is a function of the x axis length and how many bars are in total

			int x = 100+barWidth, barHeight; //x is the x coordinate of the top left point of the bar
			for(int i=0; i<data.getNum(); i++){
				g.setColor(new Color((int)(Math.random()*150)+50,(int)(Math.random()*150)+50,(int)(Math.random()*150)+50)); //make colour of bar random
				barHeight = getBarHeight(i, tick); //get the y coordinate of the top left point of the bar
				g.fillRect(x, barHeight, barWidth, height-barHeight); //draw a rectangle for the bar
				g.setColor(Color.BLACK); //label the bar
				g.drawString(data.getElementCat(i),x,height+20);
				x += 2*barWidth;
			}
			g.drawString("Category", 400,550); //x axis label
			AffineTransform at = new AffineTransform(); //rotate the frame
	        at.setToRotation(Math.toRadians(270), 400, 300);
	        g2.setTransform(at);
	        g2.drawString("Number of Elements", 375, -50); //y axis label
		}
	}
}

