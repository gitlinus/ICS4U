/*
Linus Chen
ArrayList GUI
ICS4U1
*/

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CL_ArrayList extends JFrame{

	//Declare variables
	CL_Names data, results;
	JButton init, reset, add, remove, search, sort;
	JLabel first, last;
	JTextField insertF, insertL, searchFor;
	JTextArea left, right;
	JComboBox select;
	JPanel top1, top2, bottom, content; //difference panels

	public CL_ArrayList(){ //Constructor
		super("ArrayList Problem Set");

		//initialize the variables
		data = new CL_Names();
		results = new CL_Names();
		content = new JPanel();
		content.setLayout(new FlowLayout());
		top1 = new JPanel();
		top1.setLayout(new FlowLayout());
		top2 = new JPanel();
		top2.setLayout(new FlowLayout());
		bottom = new JPanel();
		bottom.setLayout(new FlowLayout());

		init = new JButton("Choose File");
		reset = new JButton("Reset");
		remove = new JButton("Remove");
		sort = new JButton("Sort");
		search = new JButton("Search");
		add = new JButton("Add");
		select = new JComboBox(data.getList().toArray());

		first = new JLabel("First Name: ");
		last = new JLabel("Last Name: ");
		insertF = new JTextField(10);
		insertL = new JTextField(10);
		searchFor = new JTextField(10);
		left = new JTextArea();
		left.setPreferredSize(new Dimension(300,450));
		right = new JTextArea();
		right.setPreferredSize(new Dimension(300,450));
		left.setEditable(false);
		right.setEditable(false);

		init.addActionListener(new ButtonListener());
		reset.addActionListener(new ButtonListener());
		remove.addActionListener(new ButtonListener());
		sort.addActionListener(new ButtonListener());
		search.addActionListener(new ButtonListener());
		add.addActionListener(new ButtonListener());

		top1.add(init);
		top1.add(reset);
		top1.add(select);
		top1.add(remove);
		top1.add(sort);

		top2.add(first);
		top2.add(insertF);
		top2.add(last);
		top2.add(insertL);
		top2.add(add);
		top2.add(searchFor);
		top2.add(search);

		bottom.add(left);
		bottom.add(right);

		content.add(top1);
		content.add(top2);
		content.add(bottom);
		//update display
		display();
		//set window content
		setContentPane(content);
		pack();
		//set window attributes
		setSize(800,600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
	}

	public static void main(String[] args){
		CL_ArrayList arr = new CL_ArrayList();
		arr.setVisible(true);
	}

	public void display(){//update the current display
		left.setText("Current List of Names:\n"+data);
		right.setText("Names found from search:\n"+results);
		select.removeAllItems(); //remove elements from combobox
		for(Name name : data.getList()) //add theelements to the combobox
			select.addItem(name);
		top1.repaint(); 
	}

	class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){ 
			if(e.getSource()==init){ //find which buttom was pressed
				JFileChooser chooser = new JFileChooser("."); //show current directory files
				int returnVal = chooser.showOpenDialog(CL_ArrayList.this);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
			       	data = new CL_Names(chooser.getSelectedFile().getName());
			    }
			}
			else if(e.getSource()==reset){
				data = new CL_Names(); //make new empty Name ArrayLists
				results = new CL_Names();
			}
			else if(e.getSource()==add){ //converts input from textfield into Name and adds it to the current list
				if(!insertF.getText().equals("")&&!insertL.getText().equals("")){	
					String f = insertF.getText(); //get the input
					String l = insertL.getText();
					insertF.setText(""); //reset the textfields
					insertL.setText("");
					data.add(new Name(l, f)); //add to ArrayList
				}
			}
			else if(e.getSource()==remove){ //remove the selected name
				int idx = select.getSelectedIndex();
				data.remove(idx);
			}
			else if(e.getSource()==search){ 
				String find = searchFor.getText();
				if(find.length()==1) results = data.search(find.charAt(0)); //Initial inputed
				else results = data.search(find); //Surname inputed
			}
			else if(e.getSource()==sort){ //sort the names
				data.sort();
			}
			display();
		}
	}
}