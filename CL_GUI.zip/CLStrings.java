/*
Linus Chen
ICS4U1
Strings set
*/
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.lang.*;

public class CLStrings {

	static Scanner sc;

	public static boolean isPalindrome(String str){ //checks if string is a palindrome
		String temp = ""; //string to hold modified string
		for(int i=0; i<str.length(); i++){
			char c = str.charAt(i);
			if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')) temp += Character.toString(c); //only keep the letters and numbers
		}
		temp = temp.toUpperCase();	//make sure every character is same case
		int start = 0, end = temp.length() - 1;
		for(int i=0; i<str.length()/2; i++){ 
			if(temp.charAt(start)!=temp.charAt(end)) //if start and end don't match then string is not a palindrome
				return false;
			start++;
			end--;
		}
		return true;
	}

	public static String _shift(String str, int shift){ //shifts a given string by a given number
		String temp = ""; //string to store result
		for(int i=0; i<str.length(); i++){
			char c = str.charAt(i);
			if(c>='a'&&c<='z'){ int ascii=(int)c-'a'; temp += Character.toString((char)((ascii+shift)%26+'a'));}
			else if(c>='A'&&c<='Z'){ int ascii=(int)c-'A'; temp += Character.toString((char)((ascii+shift)%26+'A'));}
			else temp += Character.toString(c);
		}
		return temp;
	}

	public static String encrypt(String str, String scramble){ //scrambles a given string based on a given scrambled alphabet
		for(int i=0; i<str.length(); i++){
			char c = str.charAt(i);
			if(c>='A'&&c<='Z'){
				char replace = scramble.charAt((int)(c-'A'));
				str = str.substring(0,i) + replace + str.substring(i+1);
			}
		}
		return str;
	}

	public static String genScram(){ //generate a scramble alphabet
		String start = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		char[] scramble = new char[26];
		for(int i=0; i<26; i++) scramble[i] = start.charAt(i);
		
		for(int i=0; i<26; i++){
			int rand = (int) (Math.random()*26);
			char temp = scramble[i];
			scramble[i] = scramble[rand];
			scramble[rand] = temp;
		}
		
		String res = "";
		for(int i=0; i<26; i++) res += scramble[i];
		return res;
	}	
}