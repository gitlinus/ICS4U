/*
Linus Chen
ICS4U1
2D Arrays Assignment
*/

import java.util.*;
public class CL_2DArrays {
	static int[][] arr;
	static Scanner sc;

	public static void init(){ //initializes the array
		System.out.print("Enter number of rows: \n");
		int row = sc.nextInt();
		System.out.print("Enter number of columns: \n");
		int col = sc.nextInt();
		arr = new int[row][col];
		System.out.print("Enter array contents: \n");
		for(int i=0; i<row; i++)
			for(int j=0; j<col; j++)
				arr[i][j] = sc.nextInt();	
	}

	public static String display(){ //displays contents of the array
		String res = "";
		for(int i=0; i<arr.length; i++){
			for(int j=0; j<arr[0].length; j++)
				res += arr[i][j] + " ";
			res += "\n";
		}
		return res;
	}

	public static int totalSum(){ //calculates the sum of all elements of the array
		int total=0;
		for(int i=0; i<arr.length; i++) for (int j=0; j<arr[0].length; j++) total += arr[i][j];
		return total;
	} 

	public static int[] sumOfEachRow(){ //calculates the sum of each row of the array
		int[] res = new int[arr.length];
		for(int i=0; i<arr.length; i++) for(int j=0; j<arr[0].length; j++) res[i] += arr[i][j];
		return res;
	}

	public static int[] sumOfEachCol(){ //calculates the sum of each column of the array
		int[] res = new int[arr[0].length];
		for(int i=0; i<arr[0].length; i++) for(int j=0; j<arr.length; j++) res[i] += arr[j][i];
		return res;
	}

	public static int findMax(){ //finds the maximum value in the array
		int cur = arr[0][0];
		for(int i=0; i<arr.length; i++)
			for(int j=0; j<arr[0].length; j++)
				cur = arr[i][j]>cur ? arr[i][j]:cur;
		return cur;
	}

	public static int findMin(){ //finds the minimum value in the array
		int cur = arr[0][0];
		for(int i=0; i<arr.length; i++)
			for(int j=0; j<arr[0].length; j++)
				cur = arr[i][j]<cur ? arr[i][j]:cur;
		return cur;
	}

	public static void main(String[] args){
		sc = new Scanner(System.in);
		init();

		int choice = 0;
		do{ //menu
			System.out.println("\n\n");
			System.out.printf("2D Arrays\n");
			System.out.printf("--------------\n");
			System.out.printf("1. Display array\n");
			System.out.printf("2. Sum of all elements\n");
			System.out.printf("3. Sum of each row\n");
			System.out.printf("4. Sum of each column\n");
            System.out.printf("5. Min and Max of array\n");
            System.out.printf("6. Make new array\n");
			System.out.printf("0. Exit\n\n");
			choice = sc.nextInt();
			if(choice==1){System.out.println("The contents of the array are: \n"); System.out.print(display());}
			else if(choice==2){System.out.println("The sum of all the elements is: "+totalSum()+"\n");}
			else if(choice==3){
				int[] sum = sumOfEachRow();
				System.out.println("The following displays the sum of the nth row on the nth line\n");
				for(int i=0; i<sum.length; i++) System.out.print((i+1)+". "+sum[i]+"\n");
			}
			else if(choice==4){
				int[] sum = sumOfEachCol();
				System.out.println("The following displays the sum of the nth column on the nth line\n");
				for(int i=0; i<sum.length; i++) System.out.print((i+1)+". "+sum[i]+"\n");
			}
			else if(choice==5){
				System.out.println("The maximum of the array is "+findMax()+"\n");
				System.out.println("The minimum of the array is "+findMin()+"\n");
			}
			else if(choice==6){
				init();
			}
		}while(choice!=0);
	}
}